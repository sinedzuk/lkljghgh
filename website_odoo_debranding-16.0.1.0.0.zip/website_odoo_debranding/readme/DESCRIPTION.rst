This module remove Odoo branding on website:

* Remove "Powered by Odoo" from footer
