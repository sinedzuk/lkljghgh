* Yigit Budak <yigit@altinkaya.com.tr>
* Antonio Espinosa <antonioea@antiun.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Jairo Llopis <jairo.llopis@tecnativa.com>
* Karan Shah <karan.shah@dreambits.in>
* Dhara Solanki <dhara.solanki@initos.com>

* `Tecnativa <https://www.tecnativa.com>`_:

  * Alexandre Diaz
