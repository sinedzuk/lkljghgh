By default the option is enabled, so no additional configuration is needed.
You can always control the visibility in `Website > Customize > Brand Promotion > Remove Odoo Promotional Link`
